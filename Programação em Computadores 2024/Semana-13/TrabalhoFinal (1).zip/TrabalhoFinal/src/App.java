import controle.ImovelControle;

public class App {
    public static void main(String[] args) {
        ImovelControle controle = new ImovelControle();
        controle.iniciarSistema();
    }
}