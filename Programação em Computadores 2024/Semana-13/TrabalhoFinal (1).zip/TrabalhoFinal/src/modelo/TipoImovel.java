package modelo;

public enum TipoImovel {
    CASA,
    APARTAMENTO
}
