
public class ContaCorrente extends Conta {
    public ContaCorrente(String titular, String numeroConta, String numeroAgencia, float saldo) {
        super(titular, numeroConta, numeroAgencia, saldo, 1.0f);
    }
}
